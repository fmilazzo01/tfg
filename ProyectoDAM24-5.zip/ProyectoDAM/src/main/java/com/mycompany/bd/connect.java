package com.mycompany.bd;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Base64;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * CLASE CON METODOS PARA LA CONEXION CON LA BD Y CONSULTAS
 *
 * @author Franco
 */
public class connect {

    Connection conn = null;

    // conexion con la BD
    public static Connection ConnectDb() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/gym", "root", "123");
            System.out.println("//////////////////////////////////conexion establecida//////////////////////////////////");
            return conn;
        } catch (Exception e) {

            return null;
        }

    }

    // metodo que obtiene datos de todos los clientes de un determinado usuario
    public static ObservableList<clientes> getDatausers(String nombreUsuario) {
        Connection conn = ConnectDb();
        ObservableList<clientes> list = FXCollections.observableArrayList();
        try {
            String query = "SELECT clientes.*, MAX(pagos.membresia_hasta) AS membresia_hasta "
                    + "FROM clientes "
                    + "JOIN usuarios ON clientes.usuario_id = usuarios.id "
                    + "LEFT JOIN pagos ON clientes.id = pagos.cliente_id "
                    + "WHERE usuarios.nombre_usuario = ? "
                    + "GROUP BY clientes.id";

            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, nombreUsuario); // Establecer el nombre de usuario como parámetro

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String membresiaHastaStr = rs.getString("membresia_hasta");
                LocalDate membresiaHasta = null;
                if (membresiaHastaStr != null) {
                    membresiaHasta = LocalDate.parse(membresiaHastaStr);
                }

                list.add(new clientes(
                        Integer.parseInt(rs.getString("id")),
                        rs.getString("nombre"),
                        rs.getString("apellidos"),
                        LocalDate.parse(rs.getString("fechanacimiento")),
                        rs.getString("telefono"),
                        rs.getString("telemergencias"),
                        LocalDate.parse(rs.getString("fechainicio")),
                        membresiaHasta
                ));
            }
        } catch (NumberFormatException | SQLException e) {
            // Manejo de excepciones
        } finally {
            try {
                conn.close(); // Cerrar la conexión
            } catch (SQLException e) {
                // Manejo de excepciones
            }
        }
        return list;
    }

    // metodo que obtiene datos de todos los clientes de un determinado usuario (QUE ESTEN ATRASADOS EN EL PAGO)
    public static ObservableList<clientes> getClientesAtrasados(String nombreUsuario) {
        Connection conn = ConnectDb();
        ObservableList<clientes> list = FXCollections.observableArrayList();
        try {
            String query = "SELECT c.* FROM clientes c "
                    + "INNER JOIN pagos p ON c.id = p.cliente_id "
                    + "INNER JOIN usuarios u ON c.usuario_id = u.id "
                    + "WHERE p.membresia_hasta < CURDATE() AND u.nombre_usuario = ?";

            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, nombreUsuario); // Establecer el nombre de usuario como parámetro

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new clientes(
                        Integer.parseInt(rs.getString("id")),
                        rs.getString("nombre"),
                        rs.getString("apellidos"),
                        LocalDate.parse(rs.getString("fechanacimiento")),
                        rs.getString("telefono"),
                        rs.getString("telemergencias"),
                        LocalDate.parse(rs.getString("fechainicio")),
                        LocalDate.parse(rs.getString("membresia_hasta"))
                ));
            }
        } catch (NumberFormatException | SQLException e) {
            e.printStackTrace(); // Manejo de excepciones
        } finally {
            try {
                conn.close(); // Cerrar la conexión
            } catch (SQLException e) {
                e.printStackTrace(); // Manejo de excepciones
            }
        }
        return list;
    }

    public static double obtenerDineroRecaudadoEsteMes(String nombreUsuario) {
        double dineroRecaudado = 0.0;
        String query = "SELECT SUM(p.cantidad) AS dinero_total FROM pagos p "
                + "INNER JOIN clientes c ON p.cliente_id = c.id "
                + "INNER JOIN usuarios u ON c.usuario_id = u.id "
                + "WHERE MONTH(p.fecha_pago) = MONTH(CURDATE()) AND u.nombre_usuario = ?";
        try (Connection conn = connect.ConnectDb(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, nombreUsuario); // Establecer el nombre de usuario como parámetro
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                dineroRecaudado = rs.getDouble("dinero_total");
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de excepciones
        }
        return dineroRecaudado;
    }

   public static boolean validarLogin(String nombreUsuario, String contrasena) {
    Connection conn = ConnectDb();
    String query = "SELECT contrasena FROM usuarios WHERE nombre_usuario = ?";

    try (PreparedStatement ps = conn.prepareStatement(query)) {
        ps.setString(1, nombreUsuario);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            String hashedPasswordFromDB = rs.getString("contrasena");
            String hashedPassword = hashPassword(contrasena); // Hashear la contrasena 

            // Comparar las contrasenas hasheadas
            return hashedPasswordFromDB.equals(hashedPassword);
        } else {
            //
            return false;
        }
    } catch (SQLException | NoSuchAlgorithmException e) {
        e.printStackTrace();
        return false;
    } finally {
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


   public static boolean registrarUsuario(String nombreUsuario, String contrasena, String email, String direccion, String telefono, String nombreGym) {
    Connection conn = ConnectDb();
    String query = "INSERT INTO usuarios (nombre_usuario, contrasena, email, direccion, telefono, gimnasio_nombre) VALUES (?, ?, ?, ?, ?, ?)";

    try (PreparedStatement ps = conn.prepareStatement(query)) {
        String hashedPassword = hashPassword(contrasena); // cifro la contrasena

        ps.setString(1, nombreUsuario);
        ps.setString(2, hashedPassword); // almaceno la contrasena cifrada en la bd
        ps.setString(3, email);
        ps.setString(4, direccion);
        ps.setString(5, telefono);
        ps.setString(6, nombreGym);

        int rowsAffected = ps.executeUpdate();
        return rowsAffected > 0; // si almenos se inserto una fila fue correcto
    } catch (SQLException | NoSuchAlgorithmException e) {
        e.printStackTrace();
        return false;
    } finally {
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

    // METODO QUE COMPRUEBA SI YA EXISTE ESE EMAIL EN LA BD
    public static boolean comprobarEMAILRegistrado(String email) {
        String query = "SELECT COUNT(*) AS count FROM usuarios WHERE email = ?";

        try (Connection conn = ConnectDb(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt("count") > 0;
            }
        } catch (SQLException e) {
        }

        return false; // En caso de error, devuelve falso por precaución
    }

    // METODO QUE COMPRUEBA SI YA EXISTE ESE nombre de usuario EN LA BD
    public static boolean comprobarSiUsuarioExistente(String nombreUsuario) {
        String query = "SELECT COUNT(*) AS count FROM usuarios WHERE nombre_usuario = ?";

        try (Connection conn = ConnectDb(); PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, nombreUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt("count") > 0;
            }
        } catch (SQLException e) {
        }

        return false;
    }

        // metodo para hashear la contraseña usando SHA-256
    private static String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(password.getBytes());
        return Base64.getEncoder().encodeToString(hash);
    }

    // metodo para cambiar la contraseña por correo electrónico
    public static boolean cambiarContrasenaPorEmail(String email, String nuevaContrasena) {
        Connection conn = ConnectDb();
        if (conn == null) {
            return false; // No se pudo establecer la conexión
        }
        
        String query = "UPDATE usuarios SET contrasena = ? WHERE email = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            // Hashear la nueva contraseña
            String hashedPassword = hashPassword(nuevaContrasena);
            
            ps.setString(1, hashedPassword);
            ps.setString(2, email);
            
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Si se actualizó al menos una fila, el cambio fue exitoso
        } catch (SQLException | NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                conn.close(); 
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static boolean validarContrasena(String contrasena) {
        return contrasena.length() >= 6 && contrasena.matches("^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{6,}$");
    }
    
    
    
}
