/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectodam;

import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;

/**
 *
 * @author Franco
 */
public class Metodos {
    
    
        private void togglePasswordVisibility(PasswordField passwordField, Button toggleButton) {
        toggleButton.setOnAction(event -> {
            if (passwordField.isVisible()) {
                passwordField.setVisible(false);
                passwordField.setText(passwordField.getText()); // Para ocultar el texto
                toggleButton.setText("Mostrar contraseña");
            } else {
                passwordField.setVisible(true);
                toggleButton.setText("Ocultar contraseña");
            }
        });
    }
    
    
}
